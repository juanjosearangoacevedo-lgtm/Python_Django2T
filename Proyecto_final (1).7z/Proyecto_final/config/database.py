import mysql.connector
from mysql.connector import Error
import os
from dotenv import load_dotenv

# Cargar variables de entorno desde el archivo .env
load_dotenv()

def get_db_connection():
    try:
        connection = mysql.connector.connect(
            host=os.getenv('DB_HOST', 'local_host'),
            user=os.getenv('DB_USER', 'bryan'),
            password=os.getenv('DB_PASSWORD' 'brayan123'),
            database=os.getenv('DB_NAME' 'inder_esports')
        )
        if connection.is_connected():
            return connection
    except Error as e:
        print(f"Error al conectar a la base de datos: {e}")
        return None
