from flask import Flask
from dotenv import load_dotenv

# Importar Blueprints
from routes.equipoRoutes import equipo_bp
from routes.juegoRoutes import juego_bp
from routes.plataformaRoutes import plataforma_bp

# Cargar variables de entorno
load_dotenv()

def create_app():
    """
    Función de fábrica para crear y configurar la aplicación Flask.
    """
    app = Flask(__name__)

    # Registrar Blueprints
    app.register_blueprint(equipo_bp, url_prefix="/api")
    app.register_blueprint(juego_bp, url_prefix="/api")
    app.register_blueprint(plataforma_bp, url_prefix="/api")

    @app.route('/')
    def index():
        return "Bienvenido a la API de Gestión de E-Sports: Equipos, Juegos y Plataformas"

    return app


if __name__ == '__main__':
    app = create_app()
    app.run(debug=True, port=5000)
