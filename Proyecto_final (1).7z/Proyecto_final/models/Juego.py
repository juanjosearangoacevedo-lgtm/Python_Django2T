class Juego:
    def __init__(self, id: int, nombre: str, clasificacion_ESRB: str,
                 estudio_dev: str, plataformas_disponibles: str,
                 numero_jugadores: str, tipo: str,
                 existencias_inventario: int, plataforma_id: int):
        
        self.id = id
        self.nombre = nombre
        self.clasificacion_ESRB = clasificacion_ESRB
        self.estudio_dev = estudio_dev
        self.plataformas_disponibles = plataformas_disponibles
        self.numero_jugadores = numero_jugadores
        self.tipo = tipo
        self.existencias_inventario = existencias_inventario
        self.plataforma_id = plataforma_id

    def __str__(self):
        return (f"Juego(id={self.id}, nombre='{self.nombre}', "
                f"clasificacion_ESRB='{self.clasificacion_ESRB}', "
                f"estudio_dev='{self.estudio_dev}', "
                f"plataformas_disponibles='{self.plataformas_disponibles}', "
                f"numero_jugadores='{self.numero_jugadores}', tipo='{self.tipo}', "
                f"existencias_inventario={self.existencias_inventario}, "
                f"plataforma_id={self.plataforma_id})")
