class Plataforma:
    def _init_(self, id: int, nombre: str, marca: str):
        self.id = id
        self.nombre = nombre
        self.marca = marca

    def _str_(self):
        return f"Plataforma(id={self.id}, nombre='{self.nombre}', marca='{self.marca}')"