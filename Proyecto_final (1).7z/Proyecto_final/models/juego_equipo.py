class equipo_juego:
    def _init_(self, id: int, nombre: str, horas: int, nivel: int, juego: str):
        self.id = id
        self.nombre = nombre
        self.horas = horas
        self.nivel = nivel
        self.juego = juego  # Puede ser un ID o un nombre, depende del modelo

    def _str_(self):
        return (f"Equipo(id={self.id}, nombre='{self.nombre}', horas={self.horas}, "
                f"nivel={self.nivel}, juego='{self.juego}')")