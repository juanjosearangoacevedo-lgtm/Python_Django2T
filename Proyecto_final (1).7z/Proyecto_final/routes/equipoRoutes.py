from flask import Blueprint, request, jsonify
from services.equipoService import EquipoService

equipo_bp = Blueprint('equipo_bp', __name__)

@equipo_bp.route('/equipos', methods=['GET'])
def get_equipos():
    equipos = EquipoService.get_all_equipos()
    return jsonify([e.__dict__ for e in equipos]), 200


@equipo_bp.route('/equipos/<int:id>', methods=['GET'])
def get_equipo(id):
    equipo = EquipoService.get_equipo_by_id(id)
    if equipo:
        return jsonify(equipo.__dict__), 200
    return jsonify({'message': 'Equipo no encontrado'}), 404


@equipo_bp.route('/equipos', methods=['POST'])
def create_equipo():
    data = request.get_json()
    required = ['nombre', 'horas', 'nivel', 'juego_id']

    if not data or not all(k in data for k in required):
        return jsonify({'message': 'Datos incompletos'}), 400

    if EquipoService.create_equipo(data):
        return jsonify({'message': 'Equipo creado exitosamente'}), 201
    
    return jsonify({'message': 'Error al crear equipo'}), 500


@equipo_bp.route('/equipos/<int:id>', methods=['PUT'])
def update_equipo(id):
    data = request.get_json()
    required = ['nombre', 'horas', 'nivel', 'juego_id']

    if not data or not all(k in data for k in required):
        return jsonify({'message': 'Datos incompletos'}), 400

    if EquipoService.update_equipo(id, data):
        return jsonify({'message': 'Equipo actualizado exitosamente'}), 200

    return jsonify({'message': 'Error al actualizar equipo'}), 500


@equipo_bp.route('/equipos/<int:id>', methods=['DELETE'])
def delete_equipo(id):
    if EquipoService.delete_equipo(id):
        return jsonify({'message': 'Equipo eliminado exitosamente'}), 200

    return jsonify({'message': 'Error al eliminar equipo'}), 500
