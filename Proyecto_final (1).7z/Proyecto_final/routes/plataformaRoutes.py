from flask import Blueprint, request, jsonify
from services.plataformaService import PlataformaService

plataforma_bp = Blueprint('plataforma_bp', __name__)

@plataforma_bp.route('/plataformas', methods=['GET'])
def get_plataformas():
    plataformas = PlataformaService.get_all_plataformas()
    return jsonify([p.__dict__ for p in plataformas]), 200


@plataforma_bp.route('/plataformas/<int:id>', methods=['GET'])
def get_plataforma(id):
    plataforma = PlataformaService.get_plataforma_by_id(id)
    if plataforma:
        return jsonify(plataforma.__dict__), 200
    return jsonify({'message': 'Plataforma no encontrada'}), 404


@plataforma_bp.route('/plataformas', methods=['POST'])
def create_plataforma():
    data = request.get_json()
    required = ['nombre', 'marca']

    if not data or not all(k in data for k in required):
        return jsonify({'message': 'Datos incompletos'}), 400

    if PlataformaService.create_plataforma(data):
        return jsonify({'message': 'Plataforma creada exitosamente'}), 201

    return jsonify({'message': 'Error al crear plataforma'}), 500


@plataforma_bp.route('/plataformas/<int:id>', methods=['PUT'])
def update_plataforma(id):
    data = request.get_json()
    required = ['nombre', 'marca']

    if not data or not all(k in data for k in required):
        return jsonify({'message': 'Datos incompletos'}), 400

    if PlataformaService.update_plataforma(id, data):
        return jsonify({'message': 'Plataforma actualizada exitosamente'}), 200

    return jsonify({'message': 'Error al actualizar plataforma'}), 500


@plataforma_bp.route('/plataformas/<int:id>', methods=['DELETE'])
def delete_plataforma(id):
    if PlataformaService.delete_plataforma(id):
        return jsonify({'message': 'Plataforma eliminada exitosamente'}), 200

    return jsonify({'message': 'Error al eliminar plataforma'}), 500
