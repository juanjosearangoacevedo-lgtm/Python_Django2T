from flask import Blueprint, request, jsonify
from services.juegoService import JuegoService

juego_bp = Blueprint('juego_bp', __name__)



@juego_bp.route('/juegos', methods=['GET'])
def get_juegos():
    juegos = JuegoService.get_all_juego()
    return jsonify([j.__dict__ for j in juegos]), 200



@juego_bp.route('/juegos/<int:id>', methods=['GET'])
def get_juego(id):
    juego = JuegoService.get_juego_by_id(id)
    if juego:
        return jsonify(juego.__dict__), 200
    return jsonify({'message': 'Juego no encontrado'}), 404



@juego_bp.route('/juegos', methods=['POST'])
def create_juego():
    data = request.get_json()
    required = [
        'nombre', 'clasificacion_ESRB', 'estudio_dev',
        'plataformas_disponibles', 'numero_jugadores', 'tipo',
        'existencias_inventario', 'plataforma_id'
    ]

    if not data or not all(k in data for k in required):
        return jsonify({'message': 'Datos incompletos'}), 400

    if JuegoService.create_juego(data):
        return jsonify({'message': 'Juego creado exitosamente'}), 201

    return jsonify({'message': 'Error al crear juego'}), 500



@juego_bp.route('/juegos/<int:id>', methods=['PUT'])
def update_juego(id):
    data = request.get_json()
    required = [
        'nombre', 'clasificacion_ESRB', 'estudio_dev',
        'plataformas_disponibles', 'numero_jugadores', 'tipo',
        'existencias_inventario', 'plataforma_id'
    ]

    if not data or not all(k in data for k in required):
        return jsonify({'message': 'Datos incompletos'}), 400

    if JuegoService.update_juego(id, data):
        return jsonify({'message': 'Juego actualizado correctamente'}), 200
        
    return jsonify({'message': 'Error al actualizar juego'}), 500



@juego_bp.route('/juegos/<int:id>', methods=['DELETE'])
def delete_juego(id):
    if JuegoService.delete_juego(id):
        return jsonify({'message': 'Juego eliminado correctamente'}), 200

    return jsonify({'message': 'Error al eliminar juego'}), 500
