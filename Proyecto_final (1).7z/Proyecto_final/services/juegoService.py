from config.database import get_db_connection
from models.Juego import Juego


class JuegoService:

    @staticmethod
    def get_all_juego():
        conn = get_db_connection()
        juegos = []

        if conn:
            try:
                cursor = conn.cursor(dictionary=True)
                cursor.execute("SELECT * FROM juego")
                rows = cursor.fetchall()

                for row in rows:
                    juegos.append(
                        Juego(
                            id=row['id'],
                            nombre=row['nombre'],
                            clasificacion_ESRB=row['clasificacion_ESRB'],
                            estudio_dev=row['estudio_dev'],
                            plataformas_disponibles=row['plataformas_disponibles'],
                            numero_jugadores=row['numero_jugadores'],
                            tipo=row['tipo'],
                            existencias_inventario=row['existencias_inventario'],
                            plataforma_id=row['plataforma_id']
                        )
                    )

                cursor.close()
                conn.close()

            except Exception as e:
                print(f"Error retrieving juegos: {e}")

        return juegos


    @staticmethod
    def get_juego_by_id(id):
        conn = get_db_connection()
        juego = None

        if conn:
            try:
                cursor = conn.cursor(dictionary=True)
                cursor.execute("SELECT * FROM juego WHERE id = %s", (id,))
                row = cursor.fetchone()

                if row:
                    juego = Juego(
                        id=row['id'],
                        nombre=row['nombre'],
                        clasificacion_ESRB=row['clasificacion_ESRB'],
                        estudio_dev=row['estudio_dev'],
                        plataformas_disponibles=row['plataformas_disponibles'],
                        numero_jugadores=row['numero_jugadores'],
                        tipo=row['tipo'],
                        existencias_inventario=row['existencias_inventario'],
                        plataforma_id=row['plataforma_id']
                    )

                cursor.close()
                conn.close()

            except Exception as e:
                print(f"Error retrieving juego by id: {e}")

        return juego


    @staticmethod
    def create_juego(data):
        conn = get_db_connection()

        if conn:
            try:
                cursor = conn.cursor()

                sql = """
                INSERT INTO juego (
                    nombre, clasificacion_ESRB, estudio_dev, plataformas_disponibles,
                    numero_jugadores, tipo, existencias_inventario, plataforma_id
                ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                """

                values = (
                    data['nombre'],
                    data['clasificacion_ESRB'],
                    data['estudio_dev'],
                    data['plataformas_disponibles'],
                    data['numero_jugadores'],
                    data['tipo'],
                    data['existencias_inventario'],
                    data['plataforma_id']
                )

                cursor.execute(sql, values)
                conn.commit()

                cursor.close()
                conn.close()
                return True

            except Exception as e:
                print(f"Error creating juego: {e}")

        return False


    @staticmethod
    def update_juego(id, data):
        conn = get_db_connection()

        if conn:
            try:
                cursor = conn.cursor()

                sql = """
                UPDATE juego SET 
                    nombre = %s,
                    clasificacion_ESRB = %s,
                    estudio_dev = %s,
                    plataformas_disponibles = %s,
                    numero_jugadores = %s,
                    tipo = %s,
                    existencias_inventario = %s,
                    plataforma_id = %s
                WHERE id = %s
                """

                values = (
                    data['nombre'],
                    data['clasificacion_ESRB'],
                    data['estudio_dev'],
                    data['plataformas_disponibles'],
                    data['numero_jugadores'],
                    data['tipo'],
                    data['existencias_inventario'],
                    data['plataforma_id'],
                    id
                )

                cursor.execute(sql, values)
                conn.commit()

                cursor.close()
                conn.close()
                return True

            except Exception as e:
                print(f"Error updating juego: {e}")

        return False


    @staticmethod
    def delete_juego(id):
        conn = get_db_connection()

        if conn:
            try:
                cursor = conn.cursor()
                cursor.execute("DELETE FROM juego WHERE id = %s", (id,))
                conn.commit()

                cursor.close()
                conn.close()
                return True

            except Exception as e:
                print(f"Error deleting juego: {e}")

        return False
