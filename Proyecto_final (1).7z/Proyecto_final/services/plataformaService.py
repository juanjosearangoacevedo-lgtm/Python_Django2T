from config.database import get_db_connection
from models.Plataforma import Plataforma


class PlataformaService:

    @staticmethod
    def get_all_plataformas():
        conn = get_db_connection()
        plataformas = []

        if conn:
            try:
                cursor = conn.cursor(dictionary=True)
                cursor.execute("SELECT * FROM plataforma")
                rows = cursor.fetchall()

                for row in rows:
                    plataformas.append(
                        Plataforma(
                            id=row['id'],
                            nombre=row['nombre'],
                            marca=row['marca']
                        )
                    )

                cursor.close()
                conn.close()

            except Exception as e:
                print(f"Error retrieving plataformas: {e}")

        return plataformas


    @staticmethod
    def get_plataforma_by_id(id):
        conn = get_db_connection()
        plataforma = None

        if conn:
            try:
                cursor = conn.cursor(dictionary=True)
                cursor.execute("SELECT * FROM plataforma WHERE id = %s", (id,))
                row = cursor.fetchone()

                if row:
                    plataforma = Plataforma(
                        id=row['id'],
                        nombre=row['nombre'],
                        marca=row['marca']
                    )

                cursor.close()
                conn.close()

            except Exception as e:
                print(f"Error retrieving plataforma by id: {e}")

        return plataforma


    @staticmethod
    def create_plataforma(data):
        conn = get_db_connection()

        if conn:
            try:
                cursor = conn.cursor()

                sql = """
                INSERT INTO plataforma (nombre, marca)
                VALUES (%s, %s)
                """

                values = (
                    data['nombre'],
                    data['marca']
                )

                cursor.execute(sql, values)
                conn.commit()

                cursor.close()
                conn.close()
                return True

            except Exception as e:
                print(f"Error creating plataforma: {e}")

        return False


    @staticmethod
    def update_plataforma(id, data):
        conn = get_db_connection()

        if conn:
            try:
                cursor = conn.cursor()

                sql = """
                UPDATE plataforma
                SET nombre = %s, marca = %s
                WHERE id = %s
                """

                values = (
                    data['nombre'],
                    data['marca'],
                    id
                )

                cursor.execute(sql, values)
                conn.commit()

                cursor.close()
                conn.close()
                return True

            except Exception as e:
                print(f"Error updating plataforma: {e}")

        return False


    @staticmethod
    def delete_plataforma(id):
        conn = get_db_connection()

        if conn:
            try:
                cursor = conn.cursor()
                cursor.execute("DELETE FROM plataforma WHERE id = %s", (id,))
                conn.commit()

                cursor.close()
                conn.close()
                return True

            except Exception as e:
                print(f"Error deleting plataforma: {e}")

        return False
