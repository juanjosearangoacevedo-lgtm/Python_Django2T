from config.database import get_db_connection
from models.juego_equipo import equipo_juego

class EquipoService:

    @staticmethod
    def get_all_Equipo():
        conn = get_db_connection()
        equipos = []
        if conn:
            try:
                cursor = conn.cursor(dictionary=True)
                cursor.execute("SELECT * FROM equipo_juego")
                rows = cursor.fetchall()

                for row in rows:
                    equipos.append(
                        equipo_juego(
                            id=row['id'],
                            nombre=row['nombre'],
                            horas=row['horas'],
                            nivel=row['nivel'],
                            juego=row['juego'],
                            juego_id=row['juego_id']
                        )
                    )

                cursor.close()
                conn.close()
            except Exception as e:
                print(f"Error retrieving equipo_juego: {e}")
        return equipos


    @staticmethod
    def get_Equipo_by_id(id):
        conn = get_db_connection()
        equipo = None
        if conn:
            try:
                cursor = conn.cursor(dictionary=True)
                cursor.execute("SELECT * FROM equipo_juego WHERE id = %s", (id,))
                row = cursor.fetchone()

                if row:
                    equipo = equipo_juego(
                        id=row['id'],
                        nombre=row['nombre'],
                        horas=row['horas'],
                        nivel=row['nivel'],
                        juego=row['juego'],
                        juego_id=row['juego_id']
                    )

                cursor.close()
                conn.close()
            except Exception as e:
                print(f"Error retrieving equipo_juego by id: {e}")

        return equipo


    @staticmethod
    def create_Equipo(data):
        conn = get_db_connection()
        if conn:
            try:
                cursor = conn.cursor()
                sql = """
                INSERT INTO equipo_juego (nombre, horas, nivel, juego, juego_id)
                VALUES (%s, %s, %s, %s, %s)
                """

                values = (
                    data['nombre'],
                    data['horas'],
                    data['nivel'],
                    data['juego'],
                    data['juego_id']
                )

                cursor.execute(sql, values)
                conn.commit()

                cursor.close()
                conn.close()
                return True

            except Exception as e:
                print(f"Error creating equipo_juego: {e}")

        return False


    @staticmethod
    def update_Equipo(id, data):
        conn = get_db_connection()
        if conn:
            try:
                cursor = conn.cursor()

                sql = """
                UPDATE equipo_juego 
                SET nombre = %s, horas = %s, nivel = %s, juego = %s, juego_id = %s
                WHERE id = %s
                """

                values = (
                    data['nombre'],
                    data['horas'],
                    data['nivel'],
                    data['juego'],
                    data['juego_id'],
                    id
                )

                cursor.execute(sql, values)
                conn.commit()

                cursor.close()
                conn.close()
                return True

            except Exception as e:
                print(f"Error updating equipo_juego: {e}")

        return False


    @staticmethod
    def delete_Equipo(id):
        conn = get_db_connection()
        if conn:
            try:
                cursor = conn.cursor()
                cursor.execute("DELETE FROM equipo_juego WHERE id = %s", (id,))
                conn.commit()

                cursor.close()
                conn.close()
                return True

            except Exception as e:
                print(f"Error deleting equipo_juego: {e}")

        return False
